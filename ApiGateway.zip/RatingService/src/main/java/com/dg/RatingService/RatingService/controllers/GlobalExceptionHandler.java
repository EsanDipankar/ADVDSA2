    package com.dg.RatingService.RatingService.controllers;
    import com.dg.RatingService.RatingService.exceptions.IdNotFoundException;
    import org.springframework.http.HttpStatus;
    import org.springframework.http.ResponseEntity;
    import org.springframework.web.bind.annotation.ExceptionHandler;
    import org.springframework.web.bind.annotation.RestControllerAdvice;
    import com.dg.RatingService.RatingService.dto.ErrorResponse;
    import java.time.LocalDateTime;

    @RestControllerAdvice
    public class GlobalExceptionHandler {
        @ExceptionHandler(IdNotFoundException.class)
        public ResponseEntity<ErrorResponse> handleIdNotFoundException(IdNotFoundException ex){
            ErrorResponse error = new ErrorResponse(
                    HttpStatus.NOT_FOUND.value(),
                    ex.getMessage(),
                    LocalDateTime.now()
            );
            return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
        }

    }
