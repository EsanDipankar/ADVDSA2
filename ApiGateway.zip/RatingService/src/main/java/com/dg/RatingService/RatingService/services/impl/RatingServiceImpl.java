package com.dg.RatingService.RatingService.services.impl;

import com.dg.RatingService.RatingService.entities.Rating;
import com.dg.RatingService.RatingService.exceptions.IdNotFoundException;
import com.dg.RatingService.RatingService.repository.RatingRepository;
import com.dg.RatingService.RatingService.services.RatingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class RatingServiceImpl implements RatingService {
   @Autowired
   public RatingRepository ratingRepository;
    @Override
    public Rating createRating(Rating rating) {
        String ratingId= UUID.randomUUID().toString();
        rating.setRatingId(ratingId);
        return ratingRepository.save(rating);
    }

    @Override
    public Rating getRatingById(String id){
        return ratingRepository.findById(id).orElseThrow(() -> new IdNotFoundException("Rating not found with id: " + id));
    }

    @Override
    public List<Rating> getAllRatings() {
        return ratingRepository.findAll();
    }

    @Override
    public List<Rating> getallRatingByUserId(String userId) {
        return ratingRepository.findByUserId(userId);

    }

    @Override
    public List<Rating> getallRatingByHotelId(String hotelId) {
        return ratingRepository.findByHotelId(hotelId);
    }


}
