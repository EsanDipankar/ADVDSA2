package com.dg.RatingService.RatingService.controllers;

import com.dg.RatingService.RatingService.entities.Rating;
import com.dg.RatingService.RatingService.repository.RatingRepository;
import com.dg.RatingService.RatingService.services.impl.RatingServiceImpl;
import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@RestController
@RequestMapping("/ratings")
public class RatingController {


    private final RatingServiceImpl ratingService;

    public RatingController(RatingServiceImpl ratingServiceImpl){
        this.ratingService= ratingServiceImpl;
    }

    @PostMapping
    public ResponseEntity<Rating> create(@RequestBody Rating rating){
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ratingService.createRating(rating));
    }

    // get all ratings by userId
    @GetMapping("/users/{userId}")
    public ResponseEntity<List<Rating>> getRatingByUserId(@PathVariable String userId) {
        return ResponseEntity.ok(ratingService.getallRatingByUserId(userId));
    }

    // get all ratings by hotelId
    @GetMapping("/hotels/{hotelId}")
    public ResponseEntity<List<Rating>> getRatingByHotelId(@PathVariable String hotelId){
        return ResponseEntity.ok(ratingService.getallRatingByHotelId(hotelId));
    }

    // get all ratings
    @GetMapping
    public ResponseEntity<List<Rating>> getAllRatings(){
        return ResponseEntity.ok(ratingService.getAllRatings());
    }
    // get rating By Id
    @GetMapping("/{id}")
    public ResponseEntity<Rating> getAllRatings(@PathVariable String id){
        return ResponseEntity.ok(ratingService.getRatingById(id));
    }
}
