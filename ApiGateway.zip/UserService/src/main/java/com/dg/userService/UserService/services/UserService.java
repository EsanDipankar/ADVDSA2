package com.dg.userService.UserService.services;

import com.dg.userService.UserService.entities.Hotel;
import com.dg.userService.UserService.entities.User;

import java.util.List;

public interface UserService {
    // All the methods
    // create
    User SaveUser(User user);
    // GetAll user
    List<User> getAllUser();
    // getsingleUser
    User getUser(String userId);
    // Delete User
    String deleteUser(String userId);
    //update User
    User updateUser(User user);

    //Get Hotels List By UserId
    List<Hotel> getRatedAllHotels(String userId);

}
