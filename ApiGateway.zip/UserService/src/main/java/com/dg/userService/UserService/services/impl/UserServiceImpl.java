package com.dg.userService.UserService.services.impl;

import com.dg.userService.UserService.entities.Hotel;
import com.dg.userService.UserService.external.HotelService;
import com.dg.userService.UserService.external.RatingService;
import com.dg.userService.UserService.entities.Rating;
import com.dg.userService.UserService.entities.User;
import com.dg.userService.UserService.execption.ResourceNotFoundException;
import com.dg.userService.UserService.repositories.UserRepository;
import com.dg.userService.UserService.services.UserService;
import com.netflix.discovery.converters.Auto;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.slf4j.Logger;


import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
//import java.util.logging.Logger;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final RestTemplate restTemplate;
    public UserServiceImpl(UserRepository userRepository,RestTemplate restTemplate){
        this.userRepository= userRepository;
        this.restTemplate=restTemplate;
    }
    @Autowired
    private RatingService ratingService;

    @Autowired
    private HotelService hotelService;

    private static final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

    @Override
    public User SaveUser(User user) {
       String randomUserId=  UUID.randomUUID().toString();
       user.setUserId(randomUserId);
        return userRepository.save(user);
    }

//    @Override
//    public List<User> getAllUser() { // Finding all user
//        List<User> userList= new ArrayList<>();
//        userList = userRepository.findAll();
//        userList.stream().map(user -> {Rating[] ratings = restTemplate.getForObject(
//                "http://RATINGSERVICE/ratings/users/" + user.getUserId(),
//                Rating[].class
//                  );
//            List<Rating> ratingList = ratings != null
//                    ? List.of(ratings)
//                    : List.of();
//
//            user.setRatings(ratingList);
//            return user;
//        });
//        return userList;
//    }
//    @Override
//    public List<User> getAllUser(){
//            List<User> userList=userRepository.findAll();
//            for(User user: userList){
//                Rating[] ratingArray= restTemplate.getForObject("http://RATINGSERVICE/ratings/users/" + user.getUserId(), Rating[].class);
//
//                List<Rating> ratings = ratingArray == null ? List.of(): Arrays.asList(ratingArray);
//                user.setRatings(ratings);
//                userList.add(user);
//            }
//        return userList;
//    }
@Override
public List<User> getAllUser() {
    List<User> userList = userRepository.findAll();
    for (User user : userList) {
        Rating[] ratingArray = ratingService.getRatingByUserId(user.getUserId());
        List<Rating> ratings = ratingArray == null
                ? List.of()
                : Arrays.asList(ratingArray);

        user.setRatings(ratings);
    }

    return userList;
}

    @Override
    public User getUser(String userId) {
//        User user = userRepository.findById(userId)
//                .orElseThrow(() ->
//                        new ResourceNotFoundException("User with given id is not present"));
//        Rating[] ratings = restTemplate.getForObject(
//                "http://RATINGSERVICE/ratings/users/" + user.getUserId(),
//                Rating[].class
//        );
//        List<Rating> ratingList = List.of(ratings);
//        logger.info("Ratings received: {}", ratingList);
//        user.setRatings(ratingList);
//        return user;
        //get user from database with the help  of user repository

        User user = userRepository.findById(userId).orElseThrow(() -> new ResourceNotFoundException("User with given id is not found on server !! : " + userId));
        // fetch rating of the above  user from RATING SERVICE
        //http://localhost:8083/ratings/users/47e38dac-c7d0-4c40-8582-11d15f185fad

        Rating[] ratingsOfUser= ratingService.getRatingByUserId(user.getUserId());
        //Rating[] ratingsOfUser = restTemplate.getForObject("http://RATING-SERVICE/ratings/users/" + user.getUserId(), Rating[].class);
        logger.info("{} ", ratingsOfUser);
        List<Rating> ratings = Arrays.stream(ratingsOfUser).toList();
        List<Rating> ratingList = ratings.stream().map(rating -> {
            //api call to hotel service to get the hotel
            //http://localhost:8082/hotels/1cbaf36d-0b28-4173-b5ea-f1cb0bc0a791
            //ResponseEntity<Hotel> forEntity = restTemplate.getForEntity("http://HOTEL-SERVICE/hotels/"+rating.getHotelId(), Hotel.class);
            Hotel hotel = hotelService.getHotel(rating.getHotelId());
            // logger.info("response status code: {} ",forEntity.getStatusCode());
            //set the hotel to rating
            rating.setHotel(hotel);
            //return the rating
            return rating;
        }).collect(Collectors.toList());

        user.setRatings(ratingList);

        return user;
    }


    @Override
    public String deleteUser(String userId) {
        return "";
    }

    @Override
    public User updateUser(User user) {
        return null;
    }

    @Override
    public List<Hotel> getRatedAllHotels(String userId) {
        return List.of();
    }


}
