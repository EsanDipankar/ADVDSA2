package com.dg.userService.UserService.external;

import com.dg.userService.UserService.entities.Rating;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "RATINGSERVICE")
public interface RatingService {
    @GetMapping("/ratings/users/{userId}")
    Rating[] getRatingByUserId(@PathVariable("userId") String userId);

    // post
    @PostMapping("/rating")
    public Rating createRating(Rating values);

    //PUT
    @PutMapping("/ratings/{ratingId}")
    public Rating updateRating(@PathVariable("ratingId") String ratingId, Rating values);

    @DeleteMapping("/rating/{ratingId}")
    public void deleteRating(@PathVariable("ratingId") String ratingId);

}
