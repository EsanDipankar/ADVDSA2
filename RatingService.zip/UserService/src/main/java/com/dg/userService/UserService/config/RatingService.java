package com.dg.userService.UserService.config;

import com.dg.userService.UserService.entities.Rating;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "RATINGSERVICE")
public interface RatingService {
    @GetMapping("/ratings/users/{userId}")
    Rating[] getRatingByUserId(@PathVariable("userId") String userId);

}
