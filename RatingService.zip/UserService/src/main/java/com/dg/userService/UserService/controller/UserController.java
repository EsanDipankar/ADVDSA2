package com.dg.userService.UserService.controller;

import com.dg.userService.UserService.entities.User;
import com.dg.userService.UserService.services.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {

    private final UserService userService;
    public UserController(UserService userService){
        this.userService= userService;
    }
    // Create
    @PostMapping
    public ResponseEntity<User> createUser(@RequestBody User user){
        User user1= userService.SaveUser(user);
        return ResponseEntity.status(HttpStatus.CREATED).body(user1);
    }

    //single user get
    @GetMapping("/{usereId}")
    public ResponseEntity<User> getSingleUser(@PathVariable String usereId){
        User user= userService.getUser(usereId);
        return ResponseEntity.ok(user);

    }

// all user get
    @GetMapping
    public ResponseEntity<List<User>> getAllUser(){
        List<User> allUser= userService.getAllUser();
        return ResponseEntity.ok(allUser);
    }

}
