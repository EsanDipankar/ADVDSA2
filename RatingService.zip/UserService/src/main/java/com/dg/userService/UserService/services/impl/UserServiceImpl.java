package com.dg.userService.UserService.services.impl;

import com.dg.userService.UserService.config.RatingService;
import com.dg.userService.UserService.entities.Rating;
import com.dg.userService.UserService.entities.User;
import com.dg.userService.UserService.execption.ResourceNotFoundException;
import com.dg.userService.UserService.repositories.UserRepository;
import com.dg.userService.UserService.services.UserService;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.slf4j.Logger;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
//import java.util.logging.Logger;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final RestTemplate restTemplate;
    public UserServiceImpl(UserRepository userRepository,RestTemplate restTemplate){
        this.userRepository= userRepository;
        this.restTemplate=restTemplate;
    }
    @Autowired
    private RatingService ratingService;

    private static final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

    @Override
    public User SaveUser(User user) {
       String randomUserId=  UUID.randomUUID().toString();
       user.setUserId(randomUserId);
        return userRepository.save(user);
    }

//    @Override
//    public List<User> getAllUser() { // Finding all user
//        List<User> userList= new ArrayList<>();
//        userList = userRepository.findAll();
//        userList.stream().map(user -> {Rating[] ratings = restTemplate.getForObject(
//                "http://RATINGSERVICE/ratings/users/" + user.getUserId(),
//                Rating[].class
//                  );
//            List<Rating> ratingList = ratings != null
//                    ? List.of(ratings)
//                    : List.of();
//
//            user.setRatings(ratingList);
//            return user;
//        });
//        return userList;
//    }
//    @Override
//    public List<User> getAllUser(){
//            List<User> userList=userRepository.findAll();
//            for(User user: userList){
//                Rating[] ratingArray= restTemplate.getForObject("http://RATINGSERVICE/ratings/users/" + user.getUserId(), Rating[].class);
//
//                List<Rating> ratings = ratingArray == null ? List.of(): Arrays.asList(ratingArray);
//                user.setRatings(ratings);
//                userList.add(user);
//            }
//        return userList;
//    }
@Override
public List<User> getAllUser() {
    List<User> userList = userRepository.findAll();
    for (User user : userList) {
        Rating[] ratingArray = ratingService.getRatingByUserId(user.getUserId());
        List<Rating> ratings = ratingArray == null
                ? List.of()
                : Arrays.asList(ratingArray);

        user.setRatings(ratings);
    }

    return userList;
}

    @Override
    public User getUser(String userId) {

        User user = userRepository.findById(userId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("User with given id is not present"));

        Rating[] ratings = restTemplate.getForObject(
                "http://RATINGSERVICE/ratings/users/" + user.getUserId(),
                Rating[].class
        );

        List<Rating> ratingList = List.of(ratings);

        logger.info("Ratings received: {}", ratingList);

        user.setRatings(ratingList);

        return user;
    }


    @Override
    public String deleteUser(String userId) {
        return "";
    }

    @Override
    public User updateUser(User user) {
        return null;
    }
}
